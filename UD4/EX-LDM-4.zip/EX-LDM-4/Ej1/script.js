function cambiarFondoRojo() {
    const resultado = document.getElementById('resultado');
    const rojo = '<body id="fondo" class="rojo"></body>';
    const body = document.getElementById('fondo');
    body.innerHTML = rojo;
}